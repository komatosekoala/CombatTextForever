# Changelog

## 1.4.0

Housekeeping, from a read-through of the whole addon rather than from a patch note.

Fixed
- A queue of casts waiting for their damage to arrive could grow for a whole session in a
  fight where the client keeps combat data secret, because nothing ever emptied it there.

Changed
- The addon takes up much less space on your disk. The fight log behind `/ctf check` is a
  tool for checking the addon's own figures, and it was being written for everybody: it is
  now off unless you switch it on, on the Status page, and switching it off deletes what
  was kept. Nothing is written or even assembled while it is off.
- Spells you only ever cast outside combat (mounts, food, portals) no longer leave an
  entry behind for good. Entries that have learned nothing are cleared at login.
- Together these cut a saved file built up from ordinary play by roughly half.

## 1.3.0

Brought up to date with the WoW Forever beta build of October 15, 2026.

Fixed
- Blizzard's own damage numbers could appear on top of the addon's. That build added a
  Scrolling Combat Text settings page of its own (Options > Gameplay > Combat >
  Scrolling Combat Text for Self, with Text on Me and Text on Target), and the addon was
  only switching off two of the client's eleven floating combat text settings. It now
  reads the list off the client itself, so the auto-attack and pet damage settings are
  covered as well, and so will any setting a later build adds.
  *(Patch note: User Interface - "Added detailed Scrolling Combat Text options under
  Options > Gameplay > Combat > Scrolling Combat Text for Self > Text on Me/Text on
  Target".)*
- Windfury Weapon's extra attacks are shown as white swings rather than as an ability,
  matching what the game itself now does with them.
  *(Patch note: Shaman - "Windfury Weapon's attacks now appear as White hits in the
  scrolling combat text".)*
- Damage-over-time ticks that grow with each tick are recognised instead of falling back
  to the generic proc colour, so Mind Flay keeps its name and icon when Improved Mind
  Flay is talented.
  *(Patch note: Priest, Shadow - "Improved Mind Flay changes to: Each instance of damage
  of Mind Flay deals 10/20% more damage than its previous instance of damage".)*
- Switching Blizzard's numbers back on, in a fight the addon cannot read, no longer turns
  on categories you had switched off yourself. Each setting is returned to your own value
  instead of being forced on.

New
- `/ctf cvars` lists the damage settings the addon is switching off and what each was set
  to beforehand. Run it after a client patch: a new one that does not appear there is one
  drawing numbers on top of the addon's.

## 1.2.2

Fixed
- The incoming damage colour settings overlapped the damage school colours on the Appearance page

## 1.2.1

Fixed
- Damage-over-time ticks were not being recognised: ticks can crit and vary by a point, which the first version did not allow for
- Garrote's cast no longer claims the first white swing after it

## 1.2.0

New
- Damage-over-time ticks (Garrote, Rupture, Corruption) are shown as their ability with its icon instead of as white swings

## 1.1.0

New
- Pet hits are shown as their own event with "(Pet)" after the number
- Spells that land after their cast (Fireball, Frostbolt, Aimed Shot) now keep their name
- Notification for short abilities such as Slice and Dice and Blood Fury, with its own toggle and colour
- Option to show or hide ability names on damage numbers
- Colour settings for incoming melee and spell damage
- Mouseover descriptions on every checkbox
- Dropdown lists in the options in place of click-to-cycle buttons

Changed
- White swings, ranged attacks and procs are now shown while in a group
- Incoming melee damage uses Blizzard's red; incoming spell damage is coloured by school
- Reputation and skill-up notifications use the game's chat colours
- Darker default colours for the +Combat, -Combat and honor notifications
- Default text outline is now None, and ability names are off by default
- Removed the white/yellow damage summary shown after each fight

Fixed
- Raptor Strike and other abilities queued onto the next swing showed 0 damage, with the real damage shown as a white swing

## 1.0.0

- Initial release
